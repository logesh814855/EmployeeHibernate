insert into employee(id, name, last_name) 
values(100,'karthik','raj');
insert into employee (id, name, last_name) 
values(101,'lokesh' ,'kanagaraj' );
insert into employee(id, name, last_name ) 
values(102,'joseph', 'vijay');



















